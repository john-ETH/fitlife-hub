document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contact-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const fullname = document.getElementById('fullname').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    let isValid = true;

    // Validate Fullname
    if (fullname === '') {
      showError('fullname', 'error-fullname');
      isValid = false;
    } else {
      hideError('fullname', 'error-fullname');
    }

    // Validate Email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      showError('email', 'error-email');
      isValid = false;
    } else {
      hideError('email', 'error-email');
    }

    // Validate Message (อย่างน้อย 10 ตัวอักษร)
    if (message.length < 10) {
      showError('message', 'error-message');
      isValid = false;
    } else {
      hideError('message', 'error-message');
    }

    // หากถูกต้องทั้งหมด
    if (isValid) {
      document.getElementById('form-success').classList.remove('hidden');
      form.reset();
      setTimeout(() => {
        document.getElementById('form-success').classList.add('hidden');
      }, 4000);
    }
  });

  function showError(inputId, errorId) {
    document.getElementById(inputId).classList.add('border-red-500');
    document.getElementById(errorId).classList.remove('hidden');
  }

  function hideError(inputId, errorId) {
    document.getElementById(inputId).classList.remove('border-red-500');
    document.getElementById(errorId).classList.add('hidden');
  }
});