AI  Log — FitLife Hub Project**

เอกสารบันทึกประวัติการใช้งานปัญญาประดิษฐ์ (AI) ในการช่วยพัฒนาโปรเจกต์เว็บไซต์ **FitLife Hub** (จำนวน 3 รายการ)

รายการที่ 1: ออกแบบแนวคิดและโครงสร้างโปรเจกต์ (Concept & Structure)**

* **Prompt ที่ใช้:**"ลองเสนอการทำเว็ปไซต์มาสัก2-3เว็ป ข้อกำหนดการพัฒนา 1\. โครงสร้างเว็บไซต์ (อย่างน้อย 3 หน้า) 2\. HTML / CSS / JavaScript 3\. เฟรมเวิร์คและไลบรารี 4\. การออกแบบส่วนติดต่อผู้ใช้ (UI/UX) 5\. Responsive Design 6\. การเชื่อมต่อ API 7\. SEO เบื้องต้น"  
* **ผลลัพธ์ที่ได้:**  
  * แนวคิดเว็บไซต์ 3 ไอเดีย (TripWeather, FreshBite Cafe, FitLife Hub) พร้อมการเปรียบเทียบตามข้อกำหนด  
  * ได้เลือกพัฒนาไอเดียที่ 3 **"FitLife Hub"** (ศูนย์รวมการออกกำลังกายและเช็คสภาพอากาศ)  
  * โครงสร้างโฟลเดอร์โปรเจกต์และรายชื่อไฟล์ทั้งหมด (index.html, exercises.html, contact.html, style.css, main.js, api.js, validation.js)

รายการที่ 2: เขียนโค้ดโครงสร้าง HTML, CSS และ JavaScript สำหรับโปรเจกต์**

* **Prompt ที่ใช้:**"ไอเดียที่3"  
* **ผลลัพธ์ที่ได้:**  
  * โค้ด HTML5 Semantic Tags ครบทั้ง 3 หน้าพร้อม Tailwind CSS CDN และ Font Awesome  
  * ไฟล์ css/style.css สำหรับตั้งค่า Fonts (Prompt/Sarabun) และ CSS Variables รองรับ Dark/Light Mode  
  * ไฟล์ js/main.js สำหรับสลับธีม และทำเมนู Hamburger บนมือถือ  
  * ไฟล์ js/api.js สำหรับดึงข้อมูลสภาพอากาศด้วย async/await จาก Open-Meteo API พร้อมระบบ Filter ท่าออกกำลังกาย  
  * ไฟล์ js/validation.js สำหรับตรวจสอบความถูกต้องของแบบฟอร์มติดต่อเรา

รายการที่ 3: จัดทำเอกสารสรุปโปรเจกต์และตารางทดสอบ (README.md)**

* **Prompt ที่ใช้:**"ทำไฟล์README.md Sitemap, เหตุผลเลือกเฟรมเวิร์ค, ตารางทดสอบ ≥3 รายการ"  
* **ผลลัพธ์ที่ได้:**  
  * เอกสาร README.md ฉบับสมบูรณ์  
  * Sitemap แสดงโครงสร้างหน้าเว็บทั้ง 3 หน้า  
  * เหตุผลในการเลือกใช้ Tailwind CSS และ Font Awesome  
  * ตาราง Test Plan สำหรับบันทึกผลการทดสอบระบบ 5 รายการ